package com.example.quadratic_eqn_solver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
